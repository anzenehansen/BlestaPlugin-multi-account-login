<?php
class MultiAccountLoginModel extends AppModel {
    public function __construct(){
        parent::__construct();
    }
}

?>
