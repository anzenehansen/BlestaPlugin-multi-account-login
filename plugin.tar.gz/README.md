Multi Account Login
================================

Allows a client to log in to other accounts that share the same primary email address.

INSTALL
--------
Simply place in your plugin directory and install it via the staff area.

HOW TO USE
-----------
When a client logs in the plugin fetches all the accounts associated with the primary email address.  The client menu then gets a new item (default: Account Switcher).

When they click that, they are presented with a dropdown of all of the accounts associated with the user, minus the one they are currently logged into.  Once they click the button (default: "Switch Account") they will be automatically switched to the chosen profile.
