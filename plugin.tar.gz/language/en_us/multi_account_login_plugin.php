<?php
/*
 * To see this changed you have to reinstall the plugin.
 *
 * Luckily, uninstalling this doesn't (potentially) break anything.
 **/
$lang['MultiAccountLoginPlugin.name'] = "Account Switcher";
?>