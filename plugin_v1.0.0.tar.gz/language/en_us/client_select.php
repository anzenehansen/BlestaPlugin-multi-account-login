<?php
$lang["ClientSelect.switch_button"] = "Switch Account";
$lang["ClientSelect.overview"] = "Here you can switch between other accounts you may have within the company as long as your primary e-mail address is the same.";
$lang["ClientSelect.directions"] = "Just select the account from the dropdown list and click \"".$lang["ClientSelect.switch_button"]."\". If you wish to switch back just come back here.";
?>